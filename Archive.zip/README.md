# Workshop AI — WAI-095.2 Workflow Optimisation

This release refines WAI-095 Mission Control while retaining the existing Workshop AI interface and all WAI-094/WAI-095 workflows.

## Changes in WAI-095.2

### Unified Garage Health
- Mission Control now reads `getMasterGarageHealthSnapshot()` from the existing Garage Health engine.
- The Garage Health page, Command Centre, Mission Control, briefings and Workshop Intelligence now use the same score.
- Mission Control no longer maintains a separate competing health calculation.

### Mission Control operational navigation
- **VHC Follow-ups** opens **Service Manager → VHC Follow-Up**, including the active follow-up queue modal.
- **Labour Overruns** opens the operational overrun queue.
- **Customer Authorisations** opens the authorisation action queue.
- **Waiting for Parts** opens Parts & Tyres Intelligence.
- **First Time Fix Investigations** opens the FTF investigation centre.
- Capacity and live activity tiles continue to open their operational screens.

### Live synchronisation
Mission Control refreshes whenever the main Workshop AI render cycle runs and also refreshes every 60 seconds. Changes to jobs, VHC opportunities, parts, authorisations and labour therefore flow through to the live counters.

## Installation
Open `index.html` in a browser, or copy the complete folder over the previous local build. Keep all included JavaScript and CSS files together.

## Data
The application continues to use the existing browser local storage. This build does not deliberately clear or replace workshop records. Back up the current application folder and browser data before replacing a live installation.
